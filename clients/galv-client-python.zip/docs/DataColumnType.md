# DataColumnType

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Canonical URL for this object | 
**id** | **int** | Auto-assigned object identifier | 
**name** | **str** | Human-friendly identifier | 
**description** | **str** | Origins and purpose | 
**is_default** | **bool** | Whether the Column is included in the initial list of known Column Types | [optional] 
**unit** | **str** | Unit used for measuring the values in this column | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

