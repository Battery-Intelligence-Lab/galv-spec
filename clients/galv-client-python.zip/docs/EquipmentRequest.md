# EquipmentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identifier** | **str** | Unique identifier (e.g. serial number) for the equipment | 
**family** | **str** | Equipment Family this Equipment belongs to | 
**calibration_date** | **date** | Date of last calibration | [optional] 
**team** | **str** | Team this resource belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

