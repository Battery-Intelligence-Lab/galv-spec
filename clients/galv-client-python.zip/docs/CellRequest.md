# CellRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identifier** | **str** | Unique identifier (e.g. serial number) for the cell | 
**family** | **str** | Cell Family this Cell belongs to | 
**team** | **str** | Team this resource belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

