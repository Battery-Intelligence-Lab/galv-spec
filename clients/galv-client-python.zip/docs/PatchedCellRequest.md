# PatchedCellRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identifier** | **str** | Unique identifier (e.g. serial number) for the cell | [optional] 
**family** | **str** | Cell Family this Cell belongs to | [optional] 
**team** | **str** | Team this resource belongs to | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

