# PatchedCellFamilyRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**manufacturer** | **str** | Manufacturer name | [optional] 
**model** | **str** | Model number | [optional] 
**datasheet** | **str** | Link to the datasheet | [optional] 
**chemistry** | **str** | Chemistry type | [optional] 
**nominal_voltage** | **float** | Nominal voltage of the cells (in volts) | [optional] 
**nominal_capacity** | **float** | Nominal capacity of the cells (in amp hours) | [optional] 
**initial_ac_impedance** | **float** | Initial AC impedance of the cells (in ohms) | [optional] 
**initial_dc_resistance** | **float** | Initial DC resistance of the cells (in ohms) | [optional] 
**energy_density** | **float** | Energy density of the cells (in watt hours per kilogram) | [optional] 
**power_density** | **float** | Power density of the cells (in watts per kilogram) | [optional] 
**form_factor** | **str** | Physical form factor | [optional] 
**team** | **str** | Team this resource belongs to | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

