# EquipmentFamily

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**uuid** | **str** |  | 
**type** | **str** | Equipment type | 
**manufacturer** | **str** | Manufacturer name | 
**model** | **str** | Model number | 
**in_use** | **bool** |  | 
**team** | **str** | Team this resource belongs to | 
**equipment** | **list[str]** | Equipment belonging to this Equipment Family | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

