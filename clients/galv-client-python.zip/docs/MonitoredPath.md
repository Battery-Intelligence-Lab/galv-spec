# MonitoredPath

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Canonical URL for this object | 
**uuid** | **str** |  | 
**path** | **str** | Directory location on Harvester | 
**regex** | **str** |      Python.re regular expression to filter files by,      applied to full file name starting from this Path&#x27;s directory | 
**stable_time** | **int** | Number of seconds files must remain stable to be processed | [optional] 
**active** | **bool** |  | [optional] 
**files** | **list[str]** | Files on this MonitoredPath | 
**harvester** | **str** | Harvester this MonitoredPath is on | 
**team** | **str** | Team this MonitoredPath belongs to | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

