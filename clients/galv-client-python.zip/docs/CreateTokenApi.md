# swagger_client.CreateTokenApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create_token_create**](CreateTokenApi.md#create_token_create) | **POST** /create_token/ | Create a new API Token

# **create_token_create**
> KnoxTokenFull create_token_create(body)

Create a new API Token

 Access to the API is authenticated by API Tokens. When you log into the web frontend, you are issued with a temporary token to allow your browser session to function. If you wish to access the API via the Python client, or similar programmatically routes, you will likely want a token with a longer expiry time. Those tokens are created using this endpoint.     

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CreateTokenApi(swagger_client.ApiClient(configuration))
body = swagger_client.CreateKnoxTokenRequest() # CreateKnoxTokenRequest | 

try:
    # Create a new API Token
    api_response = api_instance.create_token_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CreateTokenApi->create_token_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CreateKnoxTokenRequest**](CreateKnoxTokenRequest.md)|  | 

### Return type

[**KnoxTokenFull**](KnoxTokenFull.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

