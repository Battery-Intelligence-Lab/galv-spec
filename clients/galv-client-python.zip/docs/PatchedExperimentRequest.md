# PatchedExperimentRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** | Title of the experiment | [optional] 
**description** | **str** | Description of the experiment | [optional] 
**authors** | **list[str]** | Users who created this Experiment | [optional] 
**protocol** | **dict(str, object)** | Protocol of the experiment | [optional] 
**protocol_file** | **str** | Protocol file of the experiment | [optional] 
**cycler_tests** | **list[str]** | Cycler Tests using this Experiment | [optional] 
**team** | **str** | Team this resource belongs to | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

