# CyclerTestRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cell** | **str** | Cell this Cycler Test uses | 
**equipment** | **list[str]** | Equipment this Cycler Test uses | 
**schedule** | **str** | Schedule this Cycler Test uses | 
**team** | **str** | Team this resource belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

