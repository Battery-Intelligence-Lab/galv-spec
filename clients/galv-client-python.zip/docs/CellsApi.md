# swagger_client.CellsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cells_create**](CellsApi.md#cells_create) | **POST** /cells/ | Create a Cell
[**cells_destroy**](CellsApi.md#cells_destroy) | **DELETE** /cells/{uuid}/ | Delete a Cell
[**cells_list**](CellsApi.md#cells_list) | **GET** /cells/ | View Cells
[**cells_partial_update**](CellsApi.md#cells_partial_update) | **PATCH** /cells/{uuid}/ | Update a Cell
[**cells_rdf_retrieve**](CellsApi.md#cells_rdf_retrieve) | **GET** /cells/{uuid}/rdf/ | View a Cell in RDF (JSON-LD)
[**cells_retrieve**](CellsApi.md#cells_retrieve) | **GET** /cells/{uuid}/ | View a Cell

# **cells_create**
> Cell cells_create(body)

Create a Cell

 Create an instance of a Cell by declaring its unique identifier and associated Cell Family.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellsApi(swagger_client.ApiClient(configuration))
body = swagger_client.CellRequest() # CellRequest | 

try:
    # Create a Cell
    api_response = api_instance.cells_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellsApi->cells_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CellRequest**](CellRequest.md)|  | 

### Return type

[**Cell**](Cell.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cells_destroy**
> cells_destroy(uuid)

Delete a Cell

 Cells that are not used in Cycler Tests may be deleted. Cells that _are_ used in a Cycler Tests are locked to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellsApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cell.

try:
    # Delete a Cell
    api_instance.cells_destroy(uuid)
except ApiException as e:
    print("Exception when calling CellsApi->cells_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cell. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cells_list**
> PaginatedCellList cells_list(limit=limit, offset=offset)

View Cells

 Cells are specific cells which generate data stored in Datasets/observed Files.  Searchable fields: - identifier         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellsApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View Cells
    api_response = api_instance.cells_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellsApi->cells_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedCellList**](PaginatedCellList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cells_partial_update**
> Cell cells_partial_update(uuid, body=body)

Update a Cell

 Cells that are not used in Cycler Tests may be edited. Cells that _are_ used in a Cycler Tests are locked to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellsApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cell.
body = swagger_client.PatchedCellRequest() # PatchedCellRequest |  (optional)

try:
    # Update a Cell
    api_response = api_instance.cells_partial_update(uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellsApi->cells_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cell. | 
 **body** | [**PatchedCellRequest**](PatchedCellRequest.md)|  | [optional] 

### Return type

[**Cell**](Cell.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cells_rdf_retrieve**
> Cell cells_rdf_retrieve(uuid)

View a Cell in RDF (JSON-LD)

 Dump the Cell in RDF (JSON-LD) format.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellsApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cell.

try:
    # View a Cell in RDF (JSON-LD)
    api_response = api_instance.cells_rdf_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellsApi->cells_rdf_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cell. | 

### Return type

[**Cell**](Cell.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cells_retrieve**
> Cell cells_retrieve(uuid)

View a Cell

 Cells are specific cells which generate data stored in Datasets/observed Files.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellsApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cell.

try:
    # View a Cell
    api_response = api_instance.cells_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellsApi->cells_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cell. | 

### Return type

[**Cell**](Cell.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

