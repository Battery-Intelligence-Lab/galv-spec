# Team

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**id** | **int** |  | 
**member_group** | **AllOfTeamMemberGroup** | Members of this Team | 
**admin_group** | **AllOfTeamAdminGroup** | Administrators of this Team | 
**monitored_paths** | **list[str]** |  | 
**cellfamily_resources** | **list[str]** | Cell Families belonging to this Team | 
**cell_resources** | **list[str]** | Cells belonging to this Team | 
**equipmentfamily_resources** | **list[str]** | Equipment Families belonging to this Team | 
**equipment_resources** | **list[str]** | Equipment belonging to this Team | 
**schedulefamily_resources** | **list[str]** | Schedule Families belonging to this Team | 
**schedule_resources** | **list[str]** | Schedules belonging to this Team | 
**cyclertest_resources** | **list[str]** | Cycler Tests belonging to this Team | 
**experiment_resources** | **list[str]** | Experiments belonging to this Team | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 
**name** | **str** | Human-friendly Team identifier | 
**description** | **str** | Description of the Team | [optional] 
**lab** | **str** | Lab this Team belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

