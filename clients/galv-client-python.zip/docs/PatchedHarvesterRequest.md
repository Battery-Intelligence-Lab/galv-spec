# PatchedHarvesterRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Human-friendly Harvester identifier | [optional] 
**sleep_time** | **int** | Seconds to sleep between Harvester cycles | [optional] 
**environment_variables** | **dict(str, object)** | Environment variables set on this Harvester | [optional] 
**active** | **bool** | Whether the Harvester is active | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

