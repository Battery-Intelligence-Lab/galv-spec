# PatchedCyclerTestRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cell** | **str** | Cell this Cycler Test uses | [optional] 
**equipment** | **list[str]** | Equipment this Cycler Test uses | [optional] 
**schedule** | **str** | Schedule this Cycler Test uses | [optional] 
**team** | **str** | Team this resource belongs to | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

