# swagger_client.ScheduleFamiliesApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**schedule_families_create**](ScheduleFamiliesApi.md#schedule_families_create) | **POST** /schedule_families/ | Create a Schedule Family
[**schedule_families_destroy**](ScheduleFamiliesApi.md#schedule_families_destroy) | **DELETE** /schedule_families/{uuid}/ | Delete a Schedule Family
[**schedule_families_list**](ScheduleFamiliesApi.md#schedule_families_list) | **GET** /schedule_families/ | View Equipment Families
[**schedule_families_partial_update**](ScheduleFamiliesApi.md#schedule_families_partial_update) | **PATCH** /schedule_families/{uuid}/ | Update a Schedule Family
[**schedule_families_retrieve**](ScheduleFamiliesApi.md#schedule_families_retrieve) | **GET** /schedule_families/{uuid}/ | View a Schedule Family

# **schedule_families_create**
> ScheduleFamily schedule_families_create(body)

Create a Schedule Family

 Schedule Families group together the general properties of a type of Schedule. Each Schedule is associated with a Schedule Family.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ScheduleFamiliesApi(swagger_client.ApiClient(configuration))
body = swagger_client.ScheduleFamilyRequest() # ScheduleFamilyRequest | 

try:
    # Create a Schedule Family
    api_response = api_instance.schedule_families_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleFamiliesApi->schedule_families_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ScheduleFamilyRequest**](ScheduleFamilyRequest.md)|  | 

### Return type

[**ScheduleFamily**](ScheduleFamily.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **schedule_families_destroy**
> schedule_families_destroy(uuid)

Delete a Schedule Family

 Schedule Families that do not have a Schedule associated with them may be deleted. Schedule Families that _do_ have Schedule associated with them are locked, to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ScheduleFamiliesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this schedule family.

try:
    # Delete a Schedule Family
    api_instance.schedule_families_destroy(uuid)
except ApiException as e:
    print("Exception when calling ScheduleFamiliesApi->schedule_families_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this schedule family. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **schedule_families_list**
> PaginatedScheduleFamilyList schedule_families_list(limit=limit, offset=offset)

View Equipment Families

 Equipment Families group together the general properties of a type of Equipment. Each Equipment is associated with an Equipment Family.  Searchable fields: - type - manufacturer - form_factor         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ScheduleFamiliesApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View Equipment Families
    api_response = api_instance.schedule_families_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleFamiliesApi->schedule_families_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedScheduleFamilyList**](PaginatedScheduleFamilyList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **schedule_families_partial_update**
> ScheduleFamily schedule_families_partial_update(uuid, body=body)

Update a Schedule Family

 Schedule Families that do not have a Schedule associated with them may be edited. Schedule Families that _do_ have Schedule associated with them are locked, to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ScheduleFamiliesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this schedule family.
body = swagger_client.PatchedScheduleFamilyRequest() # PatchedScheduleFamilyRequest |  (optional)

try:
    # Update a Schedule Family
    api_response = api_instance.schedule_families_partial_update(uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleFamiliesApi->schedule_families_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this schedule family. | 
 **body** | [**PatchedScheduleFamilyRequest**](PatchedScheduleFamilyRequest.md)|  | [optional] 

### Return type

[**ScheduleFamily**](ScheduleFamily.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **schedule_families_retrieve**
> ScheduleFamily schedule_families_retrieve(uuid)

View a Schedule Family

 Schedule Families group together the general properties of a type of Schedule. Each Schedule is associated with a Schedule Family.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ScheduleFamiliesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this schedule family.

try:
    # View a Schedule Family
    api_response = api_instance.schedule_families_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ScheduleFamiliesApi->schedule_families_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this schedule family. | 

### Return type

[**ScheduleFamily**](ScheduleFamily.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

