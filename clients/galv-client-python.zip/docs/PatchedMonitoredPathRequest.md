# PatchedMonitoredPathRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **str** | Directory location on Harvester | [optional] 
**regex** | **str** |      Python.re regular expression to filter files by,      applied to full file name starting from this Path&#x27;s directory | [optional] 
**stable_time** | **int** | Number of seconds files must remain stable to be processed | [optional] 
**active** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

