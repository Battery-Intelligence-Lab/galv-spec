# SchemaValidation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Canonical URL for this object | 
**id** | **int** | Auto-assigned object identifier | 
**schema** | **str** | Validation schema used | 
**validation_target** | **str** | Target of validation | 
**status** | **str** | Validation status | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 
**detail** | **dict(str, object)** | Validation detail | 
**last_update** | **datetime** | Date and time of last status update | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

