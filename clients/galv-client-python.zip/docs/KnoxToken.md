# KnoxToken

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Canonical URL for this object | 
**id** | **int** | Auto-assigned object identifier | 
**name** | **str** | Convenient human-friendly name | 
**created** | **datetime** | Date and time of creation | 
**expiry** | **datetime** | Date and time token expires (blank &#x3D; never) | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

