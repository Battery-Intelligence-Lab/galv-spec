# PatchedEquipmentFamilyRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | Equipment type | [optional] 
**manufacturer** | **str** | Manufacturer name | [optional] 
**model** | **str** | Model number | [optional] 
**team** | **str** | Team this resource belongs to | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

