# swagger_client.ValidationSchemasApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**validation_schemas_create**](ValidationSchemasApi.md#validation_schemas_create) | **POST** /validation_schemas/ | 
[**validation_schemas_destroy**](ValidationSchemasApi.md#validation_schemas_destroy) | **DELETE** /validation_schemas/{uuid}/ | 
[**validation_schemas_keys_retrieve**](ValidationSchemasApi.md#validation_schemas_keys_retrieve) | **GET** /validation_schemas/keys/ | Keys available for validation schemas
[**validation_schemas_list**](ValidationSchemasApi.md#validation_schemas_list) | **GET** /validation_schemas/ | List all Validation Schemas
[**validation_schemas_partial_update**](ValidationSchemasApi.md#validation_schemas_partial_update) | **PATCH** /validation_schemas/{uuid}/ | 
[**validation_schemas_retrieve**](ValidationSchemasApi.md#validation_schemas_retrieve) | **GET** /validation_schemas/{uuid}/ | 
[**validation_schemas_update**](ValidationSchemasApi.md#validation_schemas_update) | **PUT** /validation_schemas/{uuid}/ | 

# **validation_schemas_create**
> ValidationSchema validation_schemas_create(body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ValidationSchemasApi(swagger_client.ApiClient(configuration))
body = swagger_client.ValidationSchemaRequest() # ValidationSchemaRequest | 

try:
    api_response = api_instance.validation_schemas_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ValidationSchemasApi->validation_schemas_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ValidationSchemaRequest**](ValidationSchemaRequest.md)|  | 

### Return type

[**ValidationSchema**](ValidationSchema.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validation_schemas_destroy**
> validation_schemas_destroy(uuid)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ValidationSchemasApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this validation schema.

try:
    api_instance.validation_schemas_destroy(uuid)
except ApiException as e:
    print("Exception when calling ValidationSchemasApi->validation_schemas_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this validation schema. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validation_schemas_keys_retrieve**
> ValidationSchemaRootKeys validation_schemas_keys_retrieve()

Keys available for validation schemas

 Validation schemas contain one or more root properties that describe requirements for Galv objects. This endpoint provides the names and list URLs for each Galv object that can be validated against a schema.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ValidationSchemasApi(swagger_client.ApiClient(configuration))

try:
    # Keys available for validation schemas
    api_response = api_instance.validation_schemas_keys_retrieve()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ValidationSchemasApi->validation_schemas_keys_retrieve: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ValidationSchemaRootKeys**](ValidationSchemaRootKeys.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validation_schemas_list**
> PaginatedValidationSchemaList validation_schemas_list(limit=limit, offset=offset)

List all Validation Schemas

 Validation schemas contain one or more definitions that describe requirements for Galv objects. The possible values are available at `/keys/` and should be implemented in your schema thus:  ```json {     ...     \"$defs\": {         \"key_name\": {             ... description         },         ... and so on for any other keys     },     ... ```  For each of these schemas that is enabled, Galv will test the objects against the definition by constructing a JSON Schema file that hooks in your definitions and asserts a single object. This means you need not specify a root object (e.g. with `\"type\": \"object\"`) in your schema.  ```json {     ...     \"type\": {\"$ref\": \"#/$defs/key_name\"} } ```  Because your definitions are included locally, you can include references to other definitions in your schema,  and Galv will automatically resolve them for you.  Galv will highlight any objects that do not meet the requirements. This can allow you to specify a series of increasingly strict requirements for your lab's metadata.  Schemas are validated against _individually_, and are not checked for consistency. If you declare that a particular field is a `string` in one schema and a `number` in another,  Galv will not complain, except to issue a warning for failing to adhere to one or the other schema.  Because schemas validate objects returned from the Galv API,  schemas should expect most relational fields to be represented as URLs.   Note: there are some requirements put in place by Galv's database structure.  These will always apply, and will generate errors rather than warnings. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ValidationSchemasApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # List all Validation Schemas
    api_response = api_instance.validation_schemas_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ValidationSchemasApi->validation_schemas_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedValidationSchemaList**](PaginatedValidationSchemaList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validation_schemas_partial_update**
> ValidationSchema validation_schemas_partial_update(uuid, body=body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ValidationSchemasApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this validation schema.
body = swagger_client.PatchedValidationSchemaRequest() # PatchedValidationSchemaRequest |  (optional)

try:
    api_response = api_instance.validation_schemas_partial_update(uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ValidationSchemasApi->validation_schemas_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this validation schema. | 
 **body** | [**PatchedValidationSchemaRequest**](PatchedValidationSchemaRequest.md)|  | [optional] 

### Return type

[**ValidationSchema**](ValidationSchema.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validation_schemas_retrieve**
> ValidationSchema validation_schemas_retrieve(uuid)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ValidationSchemasApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this validation schema.

try:
    api_response = api_instance.validation_schemas_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ValidationSchemasApi->validation_schemas_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this validation schema. | 

### Return type

[**ValidationSchema**](ValidationSchema.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **validation_schemas_update**
> ValidationSchema validation_schemas_update(body, uuid)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ValidationSchemasApi(swagger_client.ApiClient(configuration))
body = swagger_client.ValidationSchemaRequest() # ValidationSchemaRequest | 
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this validation schema.

try:
    api_response = api_instance.validation_schemas_update(body, uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ValidationSchemasApi->validation_schemas_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ValidationSchemaRequest**](ValidationSchemaRequest.md)|  | 
 **uuid** | [**str**](.md)| A UUID string identifying this validation schema. | 

### Return type

[**ValidationSchema**](ValidationSchema.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

