# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **str** | Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only. | 
**email** | **str** |  | [optional] 
**first_name** | **str** |  | [optional] 
**last_name** | **str** |  | [optional] 
**url** | **str** | Canonical URL for this object | 
**id** | **int** | Auto-assigned object identifier | 
**is_staff** | **bool** | Designates whether the user can log into this admin site. | 
**is_superuser** | **bool** | Designates that this user has all permissions without explicitly assigning them. | 
**groups** | **list[str]** | Groups this user belongs to | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

