# swagger_client.TokensApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**tokens_destroy**](TokensApi.md#tokens_destroy) | **DELETE** /tokens/{id}/ | Revoke a token associated with your account.
[**tokens_list**](TokensApi.md#tokens_list) | **GET** /tokens/ | View tokens associated with your account.
[**tokens_partial_update**](TokensApi.md#tokens_partial_update) | **PATCH** /tokens/{id}/ | Change the name of a token associated with your account.
[**tokens_retrieve**](TokensApi.md#tokens_retrieve) | **GET** /tokens/{id}/ | View a token associated with your account.

# **tokens_destroy**
> tokens_destroy(id)

Revoke a token associated with your account.

 Revoking a token renders that token invalid for authenticating requests to the API. If you have tokens that are no longer needed, or that have been leaked (for example by being included in a public Git Repository), you can should revoke them so that other people cannot use them to access the API under your credentials.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokensApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this knox auth token.

try:
    # Revoke a token associated with your account.
    api_instance.tokens_destroy(id)
except ApiException as e:
    print("Exception when calling TokensApi->tokens_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this knox auth token. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tokens_list**
> PaginatedKnoxTokenList tokens_list(limit=limit, offset=offset)

View tokens associated with your account.

 List all API tokens associated with this user account. You will not be able to see the value of the tokens themselves, because these values are encrypted, but you can see the names you gave them and their expiry dates.  New Tokens cannot be created at this endpoint, use /create_token/ instead.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokensApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View tokens associated with your account.
    api_response = api_instance.tokens_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokensApi->tokens_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedKnoxTokenList**](PaginatedKnoxTokenList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tokens_partial_update**
> KnoxToken tokens_partial_update(id, body=body)

Change the name of a token associated with your account.

 Token values and expiry dates are immutable, but you can change the name you associated with a token.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokensApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this knox auth token.
body = swagger_client.PatchedKnoxTokenRequest() # PatchedKnoxTokenRequest |  (optional)

try:
    # Change the name of a token associated with your account.
    api_response = api_instance.tokens_partial_update(id, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokensApi->tokens_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this knox auth token. | 
 **body** | [**PatchedKnoxTokenRequest**](PatchedKnoxTokenRequest.md)|  | [optional] 

### Return type

[**KnoxToken**](KnoxToken.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tokens_retrieve**
> KnoxToken tokens_retrieve(id)

View a token associated with your account.

 You will not be able to see the value of the token, but you can see the name you gave it and its creation/expiry date.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.TokensApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this knox auth token.

try:
    # View a token associated with your account.
    api_response = api_instance.tokens_retrieve(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TokensApi->tokens_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this knox auth token. | 

### Return type

[**KnoxToken**](KnoxToken.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

