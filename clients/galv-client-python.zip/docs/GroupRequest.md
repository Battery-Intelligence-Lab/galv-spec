# GroupRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**add_users** | **list[str]** | Users to add | [optional] 
**remove_users** | **list[str]** | Users to remove | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

