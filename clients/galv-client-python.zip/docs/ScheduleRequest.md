# ScheduleRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**family** | **str** | Schedule Family this Schedule belongs to | 
**schedule_file** | **str** | File containing the schedule | [optional] 
**pybamm_schedule_variables** | **dict(str, object)** | Variables used in the PyBaMM.Experiment representation of the schedule | [optional] 
**team** | **str** | Team this resource belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

