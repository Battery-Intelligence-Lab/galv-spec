# CyclerTest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**uuid** | **str** |  | 
**cell** | **str** | Cell this Cycler Test uses | 
**equipment** | **list[str]** | Equipment this Cycler Test uses | 
**schedule** | **str** | Schedule this Cycler Test uses | 
**rendered_schedule** | **list[str]** | Rendered schedule | 
**team** | **str** | Team this resource belongs to | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

