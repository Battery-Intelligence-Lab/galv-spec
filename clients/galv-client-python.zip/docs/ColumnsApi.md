# swagger_client.ColumnsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**columns_list**](ColumnsApi.md#columns_list) | **GET** /columns/ | View Columns to which you have access
[**columns_retrieve**](ColumnsApi.md#columns_retrieve) | **GET** /columns/{id}/ | View a Column
[**columns_values_retrieve**](ColumnsApi.md#columns_values_retrieve) | **GET** /columns/{id}/values/ | View Column data as newline-separated stream of values

# **columns_list**
> PaginatedDataColumnList columns_list(file__name=file__name, file__uuid=file__uuid, limit=limit, offset=offset, type__id=type__id, type__is_required=type__is_required, type__name=type__name, type__unit__symbol=type__unit__symbol)

View Columns to which you have access

 Column instances link Column Types to the TimeseriesData they contain. You can access any Column in any Dataset to which you have access.  Searchable fields: - dataset__name - type__name (Column Type name)         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ColumnsApi(swagger_client.ApiClient(configuration))
file__name = 'file__name_example' # str |  (optional)
file__uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str |  (optional)
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)
type__id = 56 # int |  (optional)
type__is_required = true # bool |  (optional)
type__name = 'type__name_example' # str |  (optional)
type__unit__symbol = 'type__unit__symbol_example' # str |  (optional)

try:
    # View Columns to which you have access
    api_response = api_instance.columns_list(file__name=file__name, file__uuid=file__uuid, limit=limit, offset=offset, type__id=type__id, type__is_required=type__is_required, type__name=type__name, type__unit__symbol=type__unit__symbol)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ColumnsApi->columns_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **file__name** | **str**|  | [optional] 
 **file__uuid** | [**str**](.md)|  | [optional] 
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 
 **type__id** | **int**|  | [optional] 
 **type__is_required** | **bool**|  | [optional] 
 **type__name** | **str**|  | [optional] 
 **type__unit__symbol** | **str**|  | [optional] 

### Return type

[**PaginatedDataColumnList**](PaginatedDataColumnList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **columns_retrieve**
> DataColumn columns_retrieve(id)

View a Column

 Column instances link Column Types to the TimeseriesData they contain.  Searchable fields: - dataset__name - type__name (Column Type name)         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ColumnsApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this data column.

try:
    # View a Column
    api_response = api_instance.columns_retrieve(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ColumnsApi->columns_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this data column. | 

### Return type

[**DataColumn**](DataColumn.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **columns_values_retrieve**
> str columns_values_retrieve(id)

View Column data as newline-separated stream of values

 View the TimeseriesData contents of the Column.  Data are presented as a stream of values separated by newlines.  Can be filtered with querystring parameters `min` and `max`, and `mod` (modulo) by specifying a sample number.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.ColumnsApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this data column.

try:
    # View Column data as newline-separated stream of values
    api_response = api_instance.columns_values_retrieve(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling ColumnsApi->columns_values_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this data column. | 

### Return type

**str**

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/html

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

