# swagger_client.FilesApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**files_list**](FilesApi.md#files_list) | **GET** /files/ | View Files on a Path you can access
[**files_partial_update**](FilesApi.md#files_partial_update) | **PATCH** /files/{uuid}/ | 
[**files_reimport_retrieve**](FilesApi.md#files_reimport_retrieve) | **GET** /files/{uuid}/reimport/ | Force a File to be re-imported
[**files_retrieve**](FilesApi.md#files_retrieve) | **GET** /files/{uuid}/ | View a File

# **files_list**
> PaginatedObservedFileList files_list(limit=limit, offset=offset)

View Files on a Path you can access

 Files are files in a directory marked as a monitored Path for a Harvester.  They are reported to Galv by the harvester program. An File will have file metadata (size, modification time), and a status representing its import state. It may be linked to HarvestErrors encountered while importing the file, and/or to Datasets representing the content of imported files.  You can see all files on any Path on which you are an Administrator or User. Harvester Administrators have access to all Files on the Harvester's Paths.  Searchable fields: - path - state         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.FilesApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View Files on a Path you can access
    api_response = api_instance.files_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FilesApi->files_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedObservedFileList**](PaginatedObservedFileList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **files_partial_update**
> ObservedFile files_partial_update(uuid)



ObservedFiles are files that exist (or have existed) in a MonitoredPath and have been reported to Galv by the Harvester.  An ObservedFile instance will have file metadata (size, modification time), and a status representing its import state. It may be linked to HarvestErrors encountered while importing the file, and/or to Datasets representing the content of imported files.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.FilesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this observed file.

try:
    api_response = api_instance.files_partial_update(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FilesApi->files_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this observed file. | 

### Return type

[**ObservedFile**](ObservedFile.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **files_reimport_retrieve**
> ObservedFile files_reimport_retrieve(uuid)

Force a File to be re-imported

 A File will usually only be imported once, provided it is created, written to, and then left alone. Files will naturally be reimported if they grow in size again. If an error was encountered while processing a file, or you have other reasons for wishing to repeat the import process, you can use this endpoint to force the harvester program to rerun the import process when it next scans the file.  *Note*: This request may be overwritten if the file changes size before it is next scanned.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.FilesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this observed file.

try:
    # Force a File to be re-imported
    api_response = api_instance.files_reimport_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FilesApi->files_reimport_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this observed file. | 

### Return type

[**ObservedFile**](ObservedFile.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **files_retrieve**
> ObservedFile files_retrieve(uuid)

View a File

 Files are files in a directory marked as a monitored Path for a Harvester.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.FilesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this observed file.

try:
    # View a File
    api_response = api_instance.files_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling FilesApi->files_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this observed file. | 

### Return type

[**ObservedFile**](ObservedFile.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

