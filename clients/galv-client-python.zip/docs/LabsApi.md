# swagger_client.LabsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**labs_create**](LabsApi.md#labs_create) | **POST** /labs/ | Create a new Lab
[**labs_destroy**](LabsApi.md#labs_destroy) | **DELETE** /labs/{id}/ | 
[**labs_list**](LabsApi.md#labs_list) | **GET** /labs/ | View all Labs
[**labs_partial_update**](LabsApi.md#labs_partial_update) | **PATCH** /labs/{id}/ | Update a Lab
[**labs_retrieve**](LabsApi.md#labs_retrieve) | **GET** /labs/{id}/ | View a single Lab

# **labs_create**
> Lab labs_create(body)

Create a new Lab

 Labs are collections of Teams that provide for wider-scale access management and administration. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.LabsApi(swagger_client.ApiClient(configuration))
body = swagger_client.LabRequest() # LabRequest | 

try:
    # Create a new Lab
    api_response = api_instance.labs_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LabsApi->labs_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**LabRequest**](LabRequest.md)|  | 

### Return type

[**Lab**](Lab.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **labs_destroy**
> labs_destroy(id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.LabsApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this lab.

try:
    api_instance.labs_destroy(id)
except ApiException as e:
    print("Exception when calling LabsApi->labs_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this lab. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **labs_list**
> PaginatedLabList labs_list(limit=limit, offset=offset)

View all Labs

 Labs are collections of Teams that provide for wider-scale access management and administration. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.LabsApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View all Labs
    api_response = api_instance.labs_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LabsApi->labs_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedLabList**](PaginatedLabList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **labs_partial_update**
> Lab labs_partial_update(id, body=body)

Update a Lab

 Labs are collections of Teams that provide for wider-scale access management and administration. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.LabsApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this lab.
body = swagger_client.PatchedLabRequest() # PatchedLabRequest |  (optional)

try:
    # Update a Lab
    api_response = api_instance.labs_partial_update(id, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LabsApi->labs_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this lab. | 
 **body** | [**PatchedLabRequest**](PatchedLabRequest.md)|  | [optional] 

### Return type

[**Lab**](Lab.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **labs_retrieve**
> Lab labs_retrieve(id)

View a single Lab

 Labs are collections of Teams that provide for wider-scale access management and administration. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.LabsApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this lab.

try:
    # View a single Lab
    api_response = api_instance.labs_retrieve(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LabsApi->labs_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this lab. | 

### Return type

[**Lab**](Lab.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

