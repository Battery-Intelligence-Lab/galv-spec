# Harvester

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Canonical URL for this object | 
**uuid** | **str** |  | 
**last_check_in** | **datetime** | Date and time of last Harvester contact | 
**lab** | **str** | Lab this Harvester belongs to | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 
**name** | **str** | Human-friendly Harvester identifier | 
**sleep_time** | **int** | Seconds to sleep between Harvester cycles | [optional] 
**environment_variables** | **dict(str, object)** | Environment variables set on this Harvester | 
**active** | **bool** | Whether the Harvester is active | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

