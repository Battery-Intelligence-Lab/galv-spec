# DataColumn

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Auto-assigned object identifier | 
**url** | **str** | Canonical URL for this object | 
**name** | **str** | Column name (assigned by harvester but overridden by Galv for core fields) | 
**name_in_file** | **str** | Column title e.g. in .tsv file headers | 
**is_required_column** | **bool** | Whether the column is one of those required by Galv | 
**file** | **str** | File this Column belongs to | 
**data_type** | **str** | Type of the data in this column | 
**type_name** | **str** | Human-friendly identifier | 
**description** | **str** | Origins and purpose | 
**unit** | **dict(str, str)** | Unit used for measuring the values in this column | 
**values** | **str** | Column values | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

