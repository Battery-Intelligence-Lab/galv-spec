# swagger_client.CyclerTestsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cycler_tests_create**](CyclerTestsApi.md#cycler_tests_create) | **POST** /cycler_tests/ | 
[**cycler_tests_destroy**](CyclerTestsApi.md#cycler_tests_destroy) | **DELETE** /cycler_tests/{uuid}/ | 
[**cycler_tests_list**](CyclerTestsApi.md#cycler_tests_list) | **GET** /cycler_tests/ | 
[**cycler_tests_partial_update**](CyclerTestsApi.md#cycler_tests_partial_update) | **PATCH** /cycler_tests/{uuid}/ | 
[**cycler_tests_retrieve**](CyclerTestsApi.md#cycler_tests_retrieve) | **GET** /cycler_tests/{uuid}/ | 

# **cycler_tests_create**
> CyclerTest cycler_tests_create(body)



Cycler Tests are the primary object in the database. They represent a single test conducted on a specific cell using specific equipment, according to a specific schedule.  The test produces a dataset which can be associated with the Cycler Test, and Cycler Tests can be grouped together into Experiments.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CyclerTestsApi(swagger_client.ApiClient(configuration))
body = swagger_client.CyclerTestRequest() # CyclerTestRequest | 

try:
    api_response = api_instance.cycler_tests_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CyclerTestsApi->cycler_tests_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CyclerTestRequest**](CyclerTestRequest.md)|  | 

### Return type

[**CyclerTest**](CyclerTest.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cycler_tests_destroy**
> cycler_tests_destroy(uuid)



Cycler Tests are the primary object in the database. They represent a single test conducted on a specific cell using specific equipment, according to a specific schedule.  The test produces a dataset which can be associated with the Cycler Test, and Cycler Tests can be grouped together into Experiments.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CyclerTestsApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cycler test.

try:
    api_instance.cycler_tests_destroy(uuid)
except ApiException as e:
    print("Exception when calling CyclerTestsApi->cycler_tests_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cycler test. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cycler_tests_list**
> PaginatedCyclerTestList cycler_tests_list(limit=limit, offset=offset)



Cycler Tests are the primary object in the database. They represent a single test conducted on a specific cell using specific equipment, according to a specific schedule.  The test produces a dataset which can be associated with the Cycler Test, and Cycler Tests can be grouped together into Experiments.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CyclerTestsApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    api_response = api_instance.cycler_tests_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CyclerTestsApi->cycler_tests_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedCyclerTestList**](PaginatedCyclerTestList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cycler_tests_partial_update**
> CyclerTest cycler_tests_partial_update(uuid, body=body)



Cycler Tests are the primary object in the database. They represent a single test conducted on a specific cell using specific equipment, according to a specific schedule.  The test produces a dataset which can be associated with the Cycler Test, and Cycler Tests can be grouped together into Experiments.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CyclerTestsApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cycler test.
body = swagger_client.PatchedCyclerTestRequest() # PatchedCyclerTestRequest |  (optional)

try:
    api_response = api_instance.cycler_tests_partial_update(uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CyclerTestsApi->cycler_tests_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cycler test. | 
 **body** | [**PatchedCyclerTestRequest**](PatchedCyclerTestRequest.md)|  | [optional] 

### Return type

[**CyclerTest**](CyclerTest.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cycler_tests_retrieve**
> CyclerTest cycler_tests_retrieve(uuid)



Cycler Tests are the primary object in the database. They represent a single test conducted on a specific cell using specific equipment, according to a specific schedule.  The test produces a dataset which can be associated with the Cycler Test, and Cycler Tests can be grouped together into Experiments.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CyclerTestsApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cycler test.

try:
    api_response = api_instance.cycler_tests_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CyclerTestsApi->cycler_tests_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cycler test. | 

### Return type

[**CyclerTest**](CyclerTest.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

