# HarvestError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** | Canonical URL for this object | 
**id** | **int** | Auto-assigned object identifier | 
**harvester** | **str** | Harvester this HarvestError belongs to | 
**file** | **str** | File this HarvestError belongs to | 
**error** | **str** | Text of the error report | 
**timestamp** | **datetime** | Date and time error was logged in the database | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

