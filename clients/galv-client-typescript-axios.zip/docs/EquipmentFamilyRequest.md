# EquipmentFamilyRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | Equipment type | 
**manufacturer** | **str** | Manufacturer name | 
**model** | **str** | Model number | 
**team** | **str** | Team this resource belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

