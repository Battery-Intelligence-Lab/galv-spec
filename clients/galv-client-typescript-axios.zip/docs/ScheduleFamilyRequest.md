# ScheduleFamilyRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**identifier** | **str** |  | 
**description** | **str** | Description of the schedule | 
**ambient_temperature** | **float** | Ambient temperature during the experiment (in degrees Celsius) | [optional] 
**pybamm_template** | **list[str]** | Template for the schedule in PyBaMM format | [optional] 
**team** | **str** | Team this resource belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

