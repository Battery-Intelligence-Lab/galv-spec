# MonitoredPathRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **str** | Directory location on Harvester | 
**regex** | **str** |      Python.re regular expression to filter files by,      applied to full file name starting from this Path&#x27;s directory | 
**stable_time** | **int** | Number of seconds files must remain stable to be processed | [optional] 
**active** | **bool** |  | [optional] 
**harvester** | **str** | Harvester this MonitoredPath is on | 
**team** | **str** | Team this MonitoredPath belongs to | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

