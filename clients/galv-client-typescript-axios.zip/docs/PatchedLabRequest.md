# PatchedLabRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Human-friendly Lab identifier | [optional] 
**description** | **str** | Description of the Lab | [optional] 
**admin_group** | **AllOfPatchedLabRequestAdminGroup** | Group of users who can edit this Lab | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

