# PatchedValidationSchemaRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**team** | **str** | Team this resource belongs to | [optional] 
**name** | **str** | Human-friendly identifier | [optional] 
**schema** | **dict(str, object)** | JSON Schema | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

