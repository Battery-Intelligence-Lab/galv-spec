# swagger_client.CellFamiliesApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cell_families_create**](CellFamiliesApi.md#cell_families_create) | **POST** /cell_families/ | Create a Cell Family
[**cell_families_destroy**](CellFamiliesApi.md#cell_families_destroy) | **DELETE** /cell_families/{uuid}/ | Delete a Cell Family
[**cell_families_list**](CellFamiliesApi.md#cell_families_list) | **GET** /cell_families/ | View Cell Families
[**cell_families_partial_update**](CellFamiliesApi.md#cell_families_partial_update) | **PATCH** /cell_families/{uuid}/ | Update a Cell Family
[**cell_families_retrieve**](CellFamiliesApi.md#cell_families_retrieve) | **GET** /cell_families/{uuid}/ | View a Cell Family

# **cell_families_create**
> CellFamily cell_families_create(body)

Create a Cell Family

 Cell Families group together the general properties of a type of Cell. Each Cell is associated with a Cell Family.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellFamiliesApi(swagger_client.ApiClient(configuration))
body = swagger_client.CellFamilyRequest() # CellFamilyRequest | 

try:
    # Create a Cell Family
    api_response = api_instance.cell_families_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellFamiliesApi->cell_families_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CellFamilyRequest**](CellFamilyRequest.md)|  | 

### Return type

[**CellFamily**](CellFamily.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cell_families_destroy**
> cell_families_destroy(uuid)

Delete a Cell Family

 Cell Families that do not have any Cells associated with them may be deleted. Cell Families that _do_ have Cells associated with them are locked, to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellFamiliesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cell family.

try:
    # Delete a Cell Family
    api_instance.cell_families_destroy(uuid)
except ApiException as e:
    print("Exception when calling CellFamiliesApi->cell_families_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cell family. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cell_families_list**
> PaginatedCellFamilyList cell_families_list(limit=limit, offset=offset)

View Cell Families

 Cell Families group together the general properties of a type of Cell. Each Cell is associated with a Cell Family.  Searchable fields: - name - manufacturer - form_factor         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellFamiliesApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View Cell Families
    api_response = api_instance.cell_families_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellFamiliesApi->cell_families_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedCellFamilyList**](PaginatedCellFamilyList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cell_families_partial_update**
> CellFamily cell_families_partial_update(uuid, body=body)

Update a Cell Family

 Cell Families that do not have any Cells associated with them may be edited. Cell Families that _do_ have Cells associated with them are locked, to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellFamiliesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cell family.
body = swagger_client.PatchedCellFamilyRequest() # PatchedCellFamilyRequest |  (optional)

try:
    # Update a Cell Family
    api_response = api_instance.cell_families_partial_update(uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellFamiliesApi->cell_families_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cell family. | 
 **body** | [**PatchedCellFamilyRequest**](PatchedCellFamilyRequest.md)|  | [optional] 

### Return type

[**CellFamily**](CellFamily.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **cell_families_retrieve**
> CellFamily cell_families_retrieve(uuid)

View a Cell Family

 Cell Families group together the general properties of a type of Cell. Each Cell is associated with a Cell Family.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.CellFamiliesApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this cell family.

try:
    # View a Cell Family
    api_response = api_instance.cell_families_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CellFamiliesApi->cell_families_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this cell family. | 

### Return type

[**CellFamily**](CellFamily.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

