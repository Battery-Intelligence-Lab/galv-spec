# swagger_client.UnitsApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**units_list**](UnitsApi.md#units_list) | **GET** /units/ | View Units
[**units_retrieve**](UnitsApi.md#units_retrieve) | **GET** /units/{id}/ | View a Unit

# **units_list**
> PaginatedDataUnitList units_list(is_default=is_default, limit=limit, name=name, offset=offset, symbol=symbol)

View Units

 Units are scientific (typically SI) units which describe how data map to quantities in the world. Some Units are predefined (e.g. seconds, volts, amps, unitless quantities), while others can be defined in experimental data.  Searchable fields: - name - symbol - description         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.UnitsApi(swagger_client.ApiClient(configuration))
is_default = true # bool |  (optional)
limit = 56 # int | Number of results to return per page. (optional)
name = 'name_example' # str |  (optional)
offset = 56 # int | The initial index from which to return the results. (optional)
symbol = 'symbol_example' # str |  (optional)

try:
    # View Units
    api_response = api_instance.units_list(is_default=is_default, limit=limit, name=name, offset=offset, symbol=symbol)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UnitsApi->units_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **is_default** | **bool**|  | [optional] 
 **limit** | **int**| Number of results to return per page. | [optional] 
 **name** | **str**|  | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 
 **symbol** | **str**|  | [optional] 

### Return type

[**PaginatedDataUnitList**](PaginatedDataUnitList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **units_retrieve**
> DataUnit units_retrieve(id)

View a Unit

 Units are scientific (typically SI) units which describe how data map to quantities in the world. Some Units are predefined (e.g. seconds, volts, amps, unitless quantities), while others can be defined in experimental data.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.UnitsApi(swagger_client.ApiClient(configuration))
id = 56 # int | A unique integer value identifying this data unit.

try:
    # View a Unit
    api_response = api_instance.units_retrieve(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling UnitsApi->units_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**| A unique integer value identifying this data unit. | 

### Return type

[**DataUnit**](DataUnit.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

