# LabRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Human-friendly Lab identifier | 
**description** | **str** | Description of the Lab | [optional] 
**admin_group** | **AllOfLabRequestAdminGroup** | Group of users who can edit this Lab | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

