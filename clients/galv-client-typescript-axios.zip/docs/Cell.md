# Cell

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**uuid** | **str** |  | 
**identifier** | **str** | Unique identifier (e.g. serial number) for the cell | 
**family** | **str** | Cell Family this Cell belongs to | 
**cycler_tests** | **list[str]** | Cycler Tests using this Cell | 
**in_use** | **bool** |  | 
**team** | **str** | Team this resource belongs to | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

