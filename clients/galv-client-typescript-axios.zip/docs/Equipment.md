# Equipment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**uuid** | **str** |  | 
**identifier** | **str** | Unique identifier (e.g. serial number) for the equipment | 
**family** | **str** | Equipment Family this Equipment belongs to | 
**calibration_date** | **date** | Date of last calibration | [optional] 
**in_use** | **bool** |  | 
**team** | **str** | Team this resource belongs to | 
**cycler_tests** | **list[str]** | Cycler Tests using this Equipment | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

