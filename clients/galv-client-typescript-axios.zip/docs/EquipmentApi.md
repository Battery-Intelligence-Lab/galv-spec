# swagger_client.EquipmentApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**equipment_create**](EquipmentApi.md#equipment_create) | **POST** /equipment/ | Create Equipment
[**equipment_destroy**](EquipmentApi.md#equipment_destroy) | **DELETE** /equipment/{uuid}/ | Delete Equipment
[**equipment_list**](EquipmentApi.md#equipment_list) | **GET** /equipment/ | View Equipment
[**equipment_partial_update**](EquipmentApi.md#equipment_partial_update) | **PATCH** /equipment/{uuid}/ | Update Equipment
[**equipment_retrieve**](EquipmentApi.md#equipment_retrieve) | **GET** /equipment/{uuid}/ | View specific Equipment

# **equipment_create**
> Equipment equipment_create(body)

Create Equipment

 Create Equipment by describing its role and purpose.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.EquipmentApi(swagger_client.ApiClient(configuration))
body = swagger_client.EquipmentRequest() # EquipmentRequest | 

try:
    # Create Equipment
    api_response = api_instance.equipment_create(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EquipmentApi->equipment_create: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**EquipmentRequest**](EquipmentRequest.md)|  | 

### Return type

[**Equipment**](Equipment.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **equipment_destroy**
> equipment_destroy(uuid)

Delete Equipment

 Equipment that is not used in Cycler Tests may be deleted. Equipment that _is_ used in a Cycler Tests is locked to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.EquipmentApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this equipment.

try:
    # Delete Equipment
    api_instance.equipment_destroy(uuid)
except ApiException as e:
    print("Exception when calling EquipmentApi->equipment_destroy: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this equipment. | 

### Return type

void (empty response body)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **equipment_list**
> PaginatedEquipmentList equipment_list(limit=limit, offset=offset)

View Equipment

 Experimental equipment used in experiments which generate Files and their Cycler Tests.  Searchable fields: - name - type         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.EquipmentApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View Equipment
    api_response = api_instance.equipment_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EquipmentApi->equipment_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedEquipmentList**](PaginatedEquipmentList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **equipment_partial_update**
> Equipment equipment_partial_update(uuid, body=body)

Update Equipment

 Equipment that is not used in Cycler Tests may be edited. Equipment that _is_ used in a Cycler Tests is locked to prevent accidental updating.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.EquipmentApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this equipment.
body = swagger_client.PatchedEquipmentRequest() # PatchedEquipmentRequest |  (optional)

try:
    # Update Equipment
    api_response = api_instance.equipment_partial_update(uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EquipmentApi->equipment_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this equipment. | 
 **body** | [**PatchedEquipmentRequest**](PatchedEquipmentRequest.md)|  | [optional] 

### Return type

[**Equipment**](Equipment.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **equipment_retrieve**
> Equipment equipment_retrieve(uuid)

View specific Equipment

 Experimental equipment used in experiments which generate Files and their Cycler Tests.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.EquipmentApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this equipment.

try:
    # View specific Equipment
    api_response = api_instance.equipment_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling EquipmentApi->equipment_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this equipment. | 

### Return type

[**Equipment**](Equipment.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

