# Lab

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**id** | **int** |  | 
**name** | **str** | Human-friendly Lab identifier | 
**description** | **str** | Description of the Lab | [optional] 
**admin_group** | **AllOfLabAdminGroup** | Group of users who can edit this Lab | 
**harvesters** | **list[str]** |  | 
**teams** | **list[str]** | Teams in this Lab | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

