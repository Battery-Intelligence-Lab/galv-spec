# ValidationSchema

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**uuid** | **str** |  | 
**team** | **str** | Team this resource belongs to | 
**name** | **str** | Human-friendly identifier | 
**schema** | **dict(str, object)** | JSON Schema | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

