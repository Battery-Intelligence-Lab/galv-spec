# ScheduleFamily

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | 
**uuid** | **str** |  | 
**identifier** | **str** |  | 
**description** | **str** | Description of the schedule | 
**ambient_temperature** | **float** | Ambient temperature during the experiment (in degrees Celsius) | [optional] 
**pybamm_template** | **list[str]** | Template for the schedule in PyBaMM format | [optional] 
**in_use** | **bool** |  | 
**team** | **str** | Team this resource belongs to | 
**schedules** | **list[str]** | Schedules belonging to this Schedule Family | 
**permissions** | [**CellPermissions**](CellPermissions.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

