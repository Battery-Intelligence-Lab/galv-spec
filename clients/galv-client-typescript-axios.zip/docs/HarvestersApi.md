# swagger_client.HarvestersApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**harvesters_list**](HarvestersApi.md#harvesters_list) | **GET** /harvesters/ | View all Harvesters
[**harvesters_partial_update**](HarvestersApi.md#harvesters_partial_update) | **PATCH** /harvesters/{uuid}/ | Update Harvester details
[**harvesters_retrieve**](HarvestersApi.md#harvesters_retrieve) | **GET** /harvesters/{uuid}/ | View a single Harvester

# **harvesters_list**
> PaginatedHarvesterList harvesters_list(limit=limit, offset=offset)

View all Harvesters

 Harvesters monitor a set of MonitoredPaths and send reports about ObservedFiles within those paths. You can view all Harvesters for any Labs you are a member of.  Searchable fields: - name         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.HarvestersApi(swagger_client.ApiClient(configuration))
limit = 56 # int | Number of results to return per page. (optional)
offset = 56 # int | The initial index from which to return the results. (optional)

try:
    # View all Harvesters
    api_response = api_instance.harvesters_list(limit=limit, offset=offset)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HarvestersApi->harvesters_list: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to return per page. | [optional] 
 **offset** | **int**| The initial index from which to return the results. | [optional] 

### Return type

[**PaginatedHarvesterList**](PaginatedHarvesterList.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **harvesters_partial_update**
> Harvester harvesters_partial_update(uuid, body=body)

Update Harvester details

 Some Harvester details can be updated after the Harvester is created. Those details are updated using this endpoint.  Only Harvester Administrators are authorised to make these changes.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.HarvestersApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this harvester.
body = swagger_client.PatchedHarvesterRequest() # PatchedHarvesterRequest |  (optional)

try:
    # Update Harvester details
    api_response = api_instance.harvesters_partial_update(uuid, body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HarvestersApi->harvesters_partial_update: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this harvester. | 
 **body** | [**PatchedHarvesterRequest**](PatchedHarvesterRequest.md)|  | [optional] 

### Return type

[**Harvester**](Harvester.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded, multipart/form-data
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **harvesters_retrieve**
> Harvester harvesters_retrieve(uuid)

View a single Harvester

 Harvesters monitor a set of MonitoredPaths and send reports about ObservedFiles within those paths.         

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: cookieAuth
configuration = swagger_client.Configuration()
configuration.api_key['sessionid'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['sessionid'] = 'Bearer'
# Configure API key authorization: harvesterAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.HarvestersApi(swagger_client.ApiClient(configuration))
uuid = '38400000-8cf0-11bd-b23e-10b96e4ef00d' # str | A UUID string identifying this harvester.

try:
    # View a single Harvester
    api_response = api_instance.harvesters_retrieve(uuid)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling HarvestersApi->harvesters_retrieve: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | [**str**](.md)| A UUID string identifying this harvester. | 

### Return type

[**Harvester**](Harvester.md)

### Authorization

[cookieAuth](../README.md#cookieAuth), [harvesterAuth](../README.md#harvesterAuth), [knoxTokenAuth](../README.md#knoxTokenAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

